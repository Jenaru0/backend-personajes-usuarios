import { Router } from "express";
import {
  createPersonajeCtrl,
  getListaPersonajeCtrl,
  getPersonajeCtrl,
  deletePersonajeCtrl,
  updatePersonajeCtrl,
} from "../controllers/personaje.controller";

const router = Router();

// Crear un nuevo personaje
router.post("/", createPersonajeCtrl);
// Listar todos los personajes activos
router.get("/list", getListaPersonajeCtrl);
// Obtener un personaje por ID
router.get("/only/:id", getPersonajeCtrl);
// Actualizar un personaje (se espera el ID en el body)
router.put("/", updatePersonajeCtrl);
// Eliminar un personaje (soft delete: flag se pone a false)
router.delete("/:id", deletePersonajeCtrl);

export { router };
