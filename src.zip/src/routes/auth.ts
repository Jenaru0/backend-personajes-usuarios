// src/routes/auth.ts
import express from "express";
import { AuthController } from "../auth/auth.controller";

// Se crea un router de Express
const router = express.Router();

// Se definen las rutas de autenticación
router.post("/register", AuthController.register);
router.post("/login", AuthController.login);

export default router;
