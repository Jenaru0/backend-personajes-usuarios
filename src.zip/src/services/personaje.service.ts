import { PrismaClient, Personaje } from "@prisma/client";
const prisma = new PrismaClient();

// Crear un nuevo personaje en la base de datos
export const createPersonajeSrv = async (data: Partial<Personaje>) => {
  if (!data.nombre) {
    throw new Error("El campo 'nombre' es obligatorio");
  }
  const personaje = await prisma.personaje.create({
    data: {
      nombre: data.nombre,
      foto: data.foto || "",
      // 'flag' se maneja automáticamente, ya que por defecto es true
    },
  });
  return personaje;
};

// Obtener la lista de todos los personajes activos (flag true)
export const getListaPersonajeSrv = async () => {
  const personajes = await prisma.personaje.findMany({
    where: { flag: true },
  });
  return personajes;
};

// Obtener un personaje por ID (solo si está activo)
export const getPersonajeSrv = async (id: number) => {
  const personaje = await prisma.personaje.findUnique({
    where: { id },
  });
  return personaje && personaje.flag ? personaje : null;
};

// Actualizar un personaje existente
export const updatePersonajeSrv = async (data: Partial<Personaje>) => {
  if (!data.id || !data.nombre) {
    throw new Error(
      "Los campos 'id' y 'nombre' son obligatorios para actualizar"
    );
  }
  const personaje = await prisma.personaje.update({
    where: { id: data.id },
    data: {
      nombre: data.nombre,
      foto: data.foto || "",
      // No modificamos 'flag' aquí; se mantiene su valor actual
    },
  });
  return personaje;
};

// Realizar un "soft delete": en lugar de borrar el registro, se cambia flag a false
export const deletePersonajeSrv = async (id: number) => {
  const personaje = await prisma.personaje.update({
    where: { id },
    data: { flag: false },
  });
  return personaje;
};
