import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

export class UsuarioService {
  // Registrar un nuevo usuario
  static async registrar(nombre: string, correo: string, contraseña: string) {
    // Verificar si el usuario ya existe
    const usuarioExistente = await prisma.user.findUnique({
      where: { correo },
    });

    if (usuarioExistente) {
      throw new Error("El usuario ya existe con este correo");
    }

    // Encriptar la contraseña
    const hashedPassword = await bcrypt.hash(contraseña, 10);

    // Crear usuario con rol REGULAR por defecto
    return await prisma.user.create({
      data: {
        nombre,
        correo,
        contraseña: hashedPassword,
        rol: "REGULAR",
      },
    });
  }

  // Buscar un usuario por correo
  static async buscarPorCorreo(correo: string) {
    return await prisma.user.findUnique({ where: { correo } });
  }
}
