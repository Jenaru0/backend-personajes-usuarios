// src/auth/auth.controller.ts
import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { UsuarioService } from "../services/usuario.service";
import dotenv from "dotenv";

// Cargar variables de entorno
dotenv.config();

// Se obtiene la clave secreta del JWT, definida en las variables de entorno
const JWT_SECRET = process.env.JWT_SECRET || "supersecreto";

export class AuthController {
  // Función para registrar un nuevo usuario
  static async register(req: Request, res: Response) {
    // Se extraen los datos del body de la petición
    const { nombre, correo, contraseña } = req.body;

    // Se llama al servicio de usuario para registrar y encriptar la contraseña
    const nuevoUsuario = await UsuarioService.registrar(
      nombre,
      correo,
      contraseña
    );

    // Se responde con el usuario creado (sin mostrar la contraseña)
    return res.status(201).json({
      message: "Usuario registrado exitosamente",
      usuario: {
        id: nuevoUsuario.id,
        nombre: nuevoUsuario.name, // Nota: en Prisma definimos el campo como "name"
        correo: nuevoUsuario.email,
        rol: nuevoUsuario.role,
      },
    });
  }

  // Función para iniciar sesión
  static async login(req: Request, res: Response) {
    // Se extraen las credenciales del body
    const { correo, contraseña } = req.body;

    // Se busca el usuario por su correo
    const usuario = await UsuarioService.buscarPorCorreo(correo);

    // Se compara la contraseña encriptada con la recibida
    if (!usuario || !(await bcrypt.compare(contraseña, usuario.password))) {
      return res.status(401).json({ error: "Credenciales inválidas" });
    }

    // Se genera un token JWT con duración de 5 minutos
    const token = jwt.sign({ id: usuario.id, rol: usuario.role }, JWT_SECRET, {
      expiresIn: "5m",
    });

    // Se responde con el token generado
    return res.json({ message: "Login exitoso", token });
  }
}
