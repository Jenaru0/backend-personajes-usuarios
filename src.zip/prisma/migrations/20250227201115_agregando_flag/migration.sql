-- AlterTable
ALTER TABLE "Personaje" ADD COLUMN     "flag" BOOLEAN NOT NULL DEFAULT true;
